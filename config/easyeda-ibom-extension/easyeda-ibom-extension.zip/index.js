async function compressWithStream(str) {
  // 1. 将字符串编码为字节流
  const stream = new CompressionStream('gzip'); // 或 'deflate'
  const writer = stream.writable.getWriter();
  writer.write(new TextEncoder().encode(str));
  writer.close();
  // 2. 读取压缩后的结果
  const compressedBuffer = await new Response(stream.readable).arrayBuffer();
  // 3. 转为 Base64 (或直接使用二进制)
  return btoa(String.fromCharCode(...new Uint8Array(compressedBuffer)));
}
async function decompressString(compressedBase64String) {
  // 1. 还原二进制数据：Base64 -> Uint8Array
  const binaryString = atob(compressedBase64String);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {bytes[i] = binaryString.charCodeAt(i);}
  // 2. 解压
  const ds = new DecompressionStream('gzip'); // 格式一定要匹配
  const decompressedStream = new Blob([bytes]).stream().pipeThrough(ds);
  // 3. 转为对象
  return JSON.parse(await new Response(decompressedStream).text());
}
document.addEventListener('DOMContentLoaded', async function() {
  // If pcbdata is already embedded (standalone HTML export), skip data collection
  if (window.pcbdata && window.config) {
    var ov2 = document.getElementById('loading-overlay');
    if (ov2) ov2.style.display = 'none';
    if (typeof window.pcbdata==='string') window.config = await decompressString(window.config);
    if (typeof window.pcbdata==='string') window.pcbdata = await decompressString(window.pcbdata);
    initBOM();
    return;
  }
  var ov = document.getElementById('loading-overlay');
  function st(m) { if(ov){var p=ov.querySelector('p');if(p)p.textContent=m;} }

  st('等待 EDA API...');
  await new Promise(function(ok,no){
    if(typeof eda!=='undefined'&&eda.pcb_PrimitiveComponent){ok();return;}
    var s=Date.now(),t=setInterval(function(){
      if(typeof eda!=='undefined'&&eda.pcb_PrimitiveComponent){clearInterval(t);ok();}
      else if(Date.now()-s>15000){clearInterval(t);no(new Error('eda API 超时'));}
    },200);
  });
  st('正在采集 PCB 数据...');
  var data = await collectPcbData();
  st('正在处理数据...');
  fixPcbData(data);
  window.pcbdata = data;
  window.config = {
    show_fabrication:false, redraw_on_drag:true, highlight_pin1:"none",
    extra_fields: [], fields:["Value","Footprint","Manufacturer","Supplier"],
    dark_mode:false, bom_view:"left-right", board_rotation:0.0,
    checkboxes:"Sourced,Placed", show_silkscreen:true, show_pads:true, layer_view:"FB",
    show_crosshair:false
  };

  // Check if export mode via storage flag
  var isExport = false;
  var exportFlag = await eda.sys_Storage.getExtensionUserConfig('ibom_export_mode');
  if (exportFlag === 'true') {
    isExport = true;
    await eda.sys_Storage.setExtensionUserConfig('ibom_export_mode', '');
  }

  if (isExport) {
    st('正在生成 HTML 文件...');
    // Read the iframe HTML template
    var templateFile = await eda.sys_FileSystem.getExtensionFile('/iframe/index.html');
    var templateHtml = await templateFile.text();
    const startIndex=templateHtml.indexOf("// === Data collector");
    const endIndex=templateHtml.indexOf("// === Auto-init",startIndex);
    if(startIndex>0&&endIndex>0){
        const before=templateHtml.substring(0,startIndex);
        const after=templateHtml.substring(endIndex);
        templateHtml=before+after
    }
    // Embed pcbdata and config as JSON, escape </ to prevent script tag breakage
    var pcbJson = await compressWithStream(JSON.stringify(data));
    var cfgJson = await compressWithStream(JSON.stringify(window.config));
    templateHtml = templateHtml.replace('var pcbdata = null;', 'var pcbdata = "' + pcbJson + '";');
    templateHtml = templateHtml.replace('var config = {};', 'var config = "' + cfgJson + '";');
    var blob = new Blob([templateHtml], {type: 'text/html'});
    var filename = (data.metadata.title || 'ibom') + '.html';
    await eda.sys_FileSystem.saveFile(blob, filename);
    st('导出完成！');
    setTimeout(function() { try { eda.sys_IFrame.closeIFrame('ibom-export'); } catch(e) {} }, 1500);
    return;
  }

  if(ov)ov.style.display='none';
  initBOM();
  console.log('[iBOM Pro] 渲染完成');
});
